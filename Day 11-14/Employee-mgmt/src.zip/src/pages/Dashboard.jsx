import { useState, useEffect } from "react";
import { motion } from "framer-motion";

import AnalyticsChart from "../components/AnalyticsChart";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import DashboardHeader from "../components/DashboardHeader";
import StatsCards from "../components/StatsCards";
import EmployeeForm from "../components/EmployeeForm";
import EmployeeList from "../components/EmployeeList";

import "../styles/Dashboard.css";

function Dashboard({
  employees,
  addEmployee,
  updateEmployee,
  deleteEmployee,
  editEmployee,
  setEditEmployee,
}) {

  const [searchTerm, setSearchTerm] = useState("");

  const [currentPage, setCurrentPage] = useState(1);

  const employeesPerPage = 10;

  const filteredEmployees = employees.filter((employee) => {

  const search = searchTerm.toLowerCase();

  return (

    employee.name.toLowerCase().includes(search) ||

    employee.department.toLowerCase().includes(search) ||

    employee.email.toLowerCase().includes(search)

  );

});

const indexOfLastEmployee = currentPage * employeesPerPage;

const indexOfFirstEmployee = indexOfLastEmployee - employeesPerPage;

const currentEmployees = filteredEmployees.slice(

  indexOfFirstEmployee,

  indexOfLastEmployee

);

const totalPages = Math.ceil(

  filteredEmployees.length / employeesPerPage

);

useEffect(() => {

  setCurrentPage(1);

}, [searchTerm]);

  return (

    <div className="layout">

      <Sidebar />

      <motion.div
        className="dashboard"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: .6 }}
      >

        <motion.div
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: .5 }}
        >
          <Navbar
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
          />
        </motion.div>

        <DashboardHeader />

        <StatsCards employees={employees} />

        <div className="dashboard-grid">

          <motion.div
            className="form-card"
            initial={{ x: -80, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{
              duration: .6,
              delay: .2
            }}
            whileHover={{
              y: -5
            }}
          >

            <EmployeeForm
              addEmployee={addEmployee}
              updateEmployee={updateEmployee}
              editEmployee={editEmployee}
            />

          </motion.div>

          <motion.div
            className="table-card"
            initial={{ x: 80, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{
              duration: .6,
              delay: .3
            }}
          >

            <EmployeeList
              employees={currentEmployees}
              onEdit={setEditEmployee}
              onDelete={deleteEmployee}
            />
            <div className="pagination">

  <button

    disabled={currentPage === 1}

    onClick={() => setCurrentPage(currentPage - 1)}

  >

    Previous

  </button>

  {

    [...Array(totalPages)].map((_, index) => (

      <button

        key={index}

        className={

          currentPage === index + 1

            ? "active-page"

            : ""

        }

        onClick={() =>

          setCurrentPage(index + 1)

        }

      >

        {index + 1}

      </button>

    ))

  }

  <button

    disabled={currentPage === totalPages}

    onClick={() =>

      setCurrentPage(currentPage + 1)

    }

  >

    Next

  </button>

</div>
          </motion.div>

        </div>

        <AnalyticsChart employees={employees} />


      </motion.div>

    </div>

  );

}

export default Dashboard;