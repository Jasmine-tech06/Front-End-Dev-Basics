import { motion } from "framer-motion";
import {
  FaBuilding,
  FaHome,
  FaUsers,
  FaUserPlus,
  FaChartPie,
  FaCog,
  FaSignOutAlt,
} from "react-icons/fa";

import "../styles/Sidebar.css";

function Sidebar() {
  return (
    <motion.aside
      className="sidebar"
      initial={{ x: -120 }}
      animate={{ x: 0 }}
      transition={{ duration: 0.7 }}
    >
      {/* Logo */}

      <motion.div
        className="sidebar-logo"
        whileHover={{ scale: 1.05 }}
      >
        <div className="logo-circle">
          <FaBuilding />
        </div>

        <div>
          <h2>EMS</h2>
          <p>Employee System</p>
        </div>
      </motion.div>

      {/* Menu */}

      <ul className="sidebar-menu">

        <motion.li whileHover={{ x: 10 }} className="active">
          <FaHome />
          <span>Dashboard</span>
        </motion.li>

        <motion.li whileHover={{ x: 10 }}>
          <FaUsers />
          <span>Employees</span>
        </motion.li>

        <motion.li whileHover={{ x: 10 }}>
          <FaUserPlus />
          <span>Add Employee</span>
        </motion.li>

        <motion.li whileHover={{ x: 10 }}>
          <FaChartPie />
          <span>Analytics</span>
        </motion.li>

        <motion.li whileHover={{ x: 10 }}>
          <FaCog />
          <span>Settings</span>
        </motion.li>

      </ul>

      {/* Bottom */}

      <motion.button
        className="logout-btn"
        whileHover={{
          scale: 1.05,
          backgroundColor: "#dc2626",
        }}
        whileTap={{ scale: .95 }}
      >
        <FaSignOutAlt />

        Logout
      </motion.button>
    </motion.aside>
  );
}

export default Sidebar;