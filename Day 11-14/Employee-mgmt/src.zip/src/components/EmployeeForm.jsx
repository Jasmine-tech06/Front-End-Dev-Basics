import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  FaUser,
  FaBuilding,
  FaEnvelope,
  FaSave,
  FaSyncAlt,
} from "react-icons/fa";

import toast from "react-hot-toast";
import "../styles/EmployeeForm.css";

function EmployeeForm({
  addEmployee,
  updateEmployee,
  editEmployee,
}) {
  const [employee, setEmployee] = useState({
    name: "",
    department: "",
    email: "",
  });

  useEffect(() => {
    if (editEmployee) {
      setEmployee(editEmployee);
    }
  }, [editEmployee]);

  const handleChange = (e) => {
    setEmployee({
      ...employee,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (
      employee.name.trim() === "" ||
      employee.department.trim() === "" ||
      employee.email.trim() === ""
    ) {
      toast.error("Please fill all fields");
      return;
    }

    if (editEmployee) {
  updateEmployee(employee);
  toast.success("Employee updated successfully");
} else {
  addEmployee(employee);
  toast.success("Employee added successfully");
}

    setEmployee({
      name: "",
      department: "",
      email: "",
    });
  };

  return (
    <motion.form
      className="employee-form"
      onSubmit={handleSubmit}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <h2>
        {editEmployee ? "Update Employee" : "Add Employee"}
      </h2>

      <div className="input-group">
        <FaUser />

        <input
          type="text"
          name="name"
          placeholder="Employee Name"
          value={employee.name}
          onChange={handleChange}
        />
      </div>

      <div className="input-group">
        <FaBuilding />

        <input
          type="text"
          name="department"
          placeholder="Department"
          value={employee.department}
          onChange={handleChange}
        />
      </div>

      <div className="input-group">
        <FaEnvelope />

        <input
          type="email"
          name="email"
          placeholder="Email Address"
          value={employee.email}
          onChange={handleChange}
        />
        <input
    type="text"
    name="image"
    placeholder="Profile Image URL"
    value={employee.image}
    onChange={handleChange}
/>
      </div>

      <motion.button
        whileHover={{
          scale: 1.04,
        }}
        whileTap={{
          scale: .96,
        }}
        type="submit"
      >
        {editEmployee ? (
          <>
            <FaSyncAlt />
            Update Employee
          </>
        ) : (
          <>
            <FaSave />
            Add Employee
          </>
        )}
      </motion.button>
    </motion.form>
  );
}

export default EmployeeForm;