import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

import "../styles/AnalyticsChart.css";

function AnalyticsChart({ employees }) {

  const departmentCount = {};

  employees.forEach((employee) => {
    departmentCount[employee.department] =
      (departmentCount[employee.department] || 0) + 1;
  });

  const data = Object.keys(departmentCount).map((dept) => ({
    name: dept,
    value: departmentCount[dept],
  }));

  const COLORS = [
    "#4f46e5",
    "#2563eb",
    "#06b6d4",
    "#22c55e",
    "#f97316",
    "#ec4899",
    "#facc15",
  ];

  return (
    <div className="chart-card">

      <h2>Employees by Department</h2>

      <ResponsiveContainer width="100%" height={350}>

        <PieChart>

          <Pie
            data={data}
            dataKey="value"
            outerRadius={120}
            label
          >

            {data.map((entry, index) => (

              <Cell
                key={index}
                fill={COLORS[index % COLORS.length]}
              />

            ))}

          </Pie>

          <Tooltip />

        </PieChart>

      </ResponsiveContainer>

    </div>
  );
}

export default AnalyticsChart;